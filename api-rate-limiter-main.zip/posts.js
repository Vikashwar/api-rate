 const posts=[
    {

        "userId":1,
        "id":1,
        "title":"Aj",
        "body":"Dil me warna dimag me v nh"
    },
    {

        "userId":1,
        "id":2,
        "title":"ddlj",
        "body":"Bade bade sehro me choti baate "
    },
    {

        "userId":1,
        "id":3,
        "title":"Gowp",
        "body":"Sabka badla lega tera faizal"
    }
]

module.exports=posts